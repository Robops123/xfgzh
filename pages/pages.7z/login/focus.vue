<template>
	<view class="outer">
		<view>请关注木塔卫士微信公众号</view>
		<view>长按二维码识别</view>
		<image src="../../static/img/gzh.jpg" mode=""></image>
	</view>
</template>

<script>
</script>

<style>
	.outer{
		padding: 30px 0 0;
		text-align: center;
		font-size: 1.6rem;
		line-height: 1.6rem;
		font-weight: bold;
	}
</style>
